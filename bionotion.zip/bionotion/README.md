# BioNotion 🧬

> A Notion-inspired bioinformatics research dashboard — converted from a Google Sheets research workflow into a fully interactive React web application.

![BioNotion Screenshot](public/screenshot.png)

## Features

- **Quick Access Panel** — dropdown-driven table switching (replicates the Google Sheets experience)
- **Detailed Biomarkers** — 12 cancer types with tumor markers, detection methods, databases & pipelines
- **Biological Databases** — GENOMICS / TRANSCRIPTOMICS / PROTEOMICS / DRUG / SINGLE CELL sections
- **Bioinformatics Workflows** — 8 workflows (NGS, Metagenomics, Metatranscriptomics, Network Analysis, Systems Biology, Synthetic Biology, Genetic Engineering, VCF Analysis)
- **LLMs & Foundation Models** — AlphaFold, ESMFold, RoseTTAFold, Atomwise, BioGPT, scBERT & more
- **Proteomics → Drug Development** — 7-step drug discovery pipeline
- **Nextflow Pipeline** — Bulk RNA-seq 6-section comprehensive workflow

## Tech Stack

- **React 18** + **Vite 5**
- **CSS Modules** for scoped styling
- **EB Garamond** + **JetBrains Mono** fonts
- Zero external UI library dependencies — pure React + CSS

## Getting Started

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/bionotion.git
cd bionotion

# 2. Install dependencies
npm install

# 3. Start dev server
npm run dev

# 4. Open in browser
# http://localhost:5173
```

## Build for Production

```bash
npm run build
# Output in /dist — ready to deploy on Vercel, Netlify, or GitHub Pages
```

## Deploy to GitHub Pages

```bash
# Install gh-pages
npm install --save-dev gh-pages

# Add to package.json scripts:
# "deploy": "gh-pages -d dist"

npm run build
npm run deploy
```

## Project Structure

```
bionotion/
├── index.html
├── vite.config.js
├── package.json
├── src/
│   ├── main.jsx              # Entry point
│   ├── App.jsx               # Root layout + state
│   ├── App.module.css
│   ├── styles/
│   │   └── global.css        # CSS variables, reset, fonts
│   ├── components/
│   │   ├── LeftPanel.jsx     # Sidebar with dropdowns + purpose text
│   │   ├── LeftPanel.module.css
│   │   ├── DataPanel.jsx     # Main data table (switches per dropdown)
│   │   ├── DataPanel.module.css
│   │   ├── WorkflowPanel.jsx # Right workflow table with selector
│   │   └── WorkflowPanel.module.css
│   └── data/
│       ├── biomarkers.js     # 12 cancer biomarker records
│       ├── workflows.js      # 8 bioinformatics workflows
│       ├── databases.js      # Biological databases by category
│       ├── llms.js           # LLMs / foundation models
│       ├── proteomics.js     # Drug development pipeline steps
│       └── pipelines.js      # Nextflow RNA-seq pipeline
└── public/
```

## Data Source

All data extracted from the **Copy_of_Bioinformatics_Research.xlsx** spreadsheet (Google Sheets), including:
- Quick Access sheet (biomarkers, workflows)
- Data sheet (all workflow lists)
- Proteomics sheet (drug development pipeline)
- Pipelines sheet (Nextflow RNA-seq)
- All sheet (LLMs, databases)

## Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/add-proteomics-section`
3. Commit your changes: `git commit -m 'Add proteomics section'`
4. Push and open a PR

## License

MIT
