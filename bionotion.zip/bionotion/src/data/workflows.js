export const workflows = {
  metagenomics: {
    title: "Meta-genomics Workflow",
    steps: {
      "Preprocessing": ["SortMeRNA", "Trimmomatic", "Fastp"],
      "Assembly": ["Trinity", "MEGAHIT"],
      "Quantification": ["Salmon", "Kallisto", "RSEM"],
      "Functional Annotation": ["eggNOG-mapper", "KEGG Mapper", "InterProScan"],
      "Pathway Analysis": ["Metacyc", "MapMan"]
    }
  },
  metatranscriptomics: {
    title: "Meta-transcriptomics Workflow",
    steps: {
      "Preprocessing": ["SortMeRNA", "Trimmomatic", "Fastp"],
      "Assembly": ["Trinity", "MEGAHIT"],
      "Quantification": ["Salmon", "Kallisto", "RSEM"],
      "Functional Annotation": ["eggNOG-mapper", "KEGG Mapper", "InterProScan"],
      "Pathway Analysis": ["Metacyc", "MapMan"]
    }
  },
  ngs: {
    title: "NGS (Next-Generation Sequencing) Workflow",
    steps: {
      "Data Analysis": ["FASTQC", "MultiQC", "Trimmomatic", "Cutadapt"],
      "Alignment": ["BWA", "Bowtie2", "STAR", "HISAT2"],
      "Variant Calling": ["GATK", "FreeBayes", "SAMtools"],
      "Assembly": ["SPAdes", "MEGAHIT", "SOAPdenovo"],
      "Annotation": ["Prokka", "RAST", "SnpEff"]
    }
  },
  network: {
    title: "Network Analysis Workflow",
    steps: {
      "Network Visualization": ["Cytoscape", "Gephi"],
      "Graph Analysis": ["igraph (R/Python)", "NetworkX (Python)"],
      "Functional Enrichment": ["STRING", "GeneMANIA"],
      "Dynamic Modeling": ["Pajek", "BioGRID"]
    }
  },
  systems: {
    title: "Systems Biology Workflow",
    steps: {
      "Modeling Tools": ["COPASI", "CellDesigner", "MATLAB SimBiology"],
      "Pathway Databases": ["KEGG", "Reactome", "BioCyc"],
      "Simulation": ["SBML", "VCell", "OpenSim"],
      "Omics Integration": ["MetaboAnalyst", "Cytoscape (ClueGO)"]
    }
  },
  synthetic: {
    title: "Synthetic Biology Workflow",
    steps: {
      "Design Tools": ["BioCAD", "Gene Designer", "TinkerCell"],
      "Simulation & Modeling": ["iBioSim", "SynBioSS", "COPASI"],
      "DNA Assembly": ["Golden Gate Assembly", "Gibson Assembly"],
      "Pathway Design": ["SBOL", "SBW"]
    }
  },
  genetic: {
    title: "Genetic Engineering Workflow",
    steps: {
      "Design & Simulation": ["Benchling", "Geneious", "SnapGene"],
      "CRISPR Tools": ["CRISPResso", "CHOPCHOP", "Cas-OFFinder"],
      "Primer Design": ["Primer3", "OligoAnalyzer"],
      "Cloning Tools": ["ApE", "PlasMapper"]
    }
  },
  vcf: {
    title: "VCF Analysis Workflow",
    steps: {
      "VCF Manipulation": ["VCFtools", "BCFtools"],
      "Annotation": ["ANNOVAR", "SnpEff", "VEP"],
      "Visualization": ["IGV", "JBrowse"],
      "Comparative Analysis": ["bedtools", "GATK"]
    }
  }
}

export const workflowOptions = [
  { value: "metagenomics", label: "Metagenomics" },
  { value: "metatranscriptomics", label: "Metatranscriptomics" },
  { value: "ngs", label: "NGS" },
  { value: "network", label: "Network Analysis" },
  { value: "systems", label: "System Biology" },
  { value: "synthetic", label: "Synthetic Biology" },
  { value: "genetic", label: "Genetic Engineering" },
  { value: "vcf", label: "VCF Analysis" }
]
