export const proteomicsSteps = [
  {
    step: "1.0",
    title: "Protein Target Identification",
    description: "Identify protein targets involved in disease pathways using protein-DNA interaction data.",
    tools: ["DeepPBS", "PeSTo", "KEGG", "STRING"],
    inputs: "Protein-DNA interaction predictions",
    outputs: "List of candidate protein targets",
    timeline: "2–3 days"
  },
  {
    step: "2.0",
    title: "Target Validation",
    description: "Validate the biological relevance of protein targets using functional and expression data.",
    tools: ["UniProt", "Gene Ontology (GO)", "DAVID", "RNA-Seq data"],
    inputs: "Candidate protein targets, expression data",
    outputs: "Validated protein targets with functional annotations",
    timeline: "3–4 days"
  },
  {
    step: "3.0",
    title: "Protein Structure Modeling",
    description: "Model the 3D structure of validated protein targets for drug binding analysis.",
    tools: ["RoseTTAFold2NA", "AlphaFold"],
    inputs: "Protein sequences of validated targets",
    outputs: "3D structural models (PDB files)",
    timeline: "3–5 days"
  },
  {
    step: "4.0",
    title: "Small Molecule Library Preparation",
    description: "Retrieve and preprocess a library of small molecules for screening.",
    tools: ["PubChem", "ZINC", "RDKit"],
    inputs: "Chemical compound databases",
    outputs: "Preprocessed small molecule library (SMILES format)",
    timeline: "2–3 days"
  },
  {
    step: "5.0",
    title: "Virtual Screening & Molecular Docking",
    description: "Screen small molecules for binding to protein targets and predict binding affinities.",
    tools: ["AutoDock Vina", "Schrödinger Glide"],
    inputs: "Protein structure (PDB) + small molecule library",
    outputs: "Ranked list of binding candidates",
    timeline: "4–6 days"
  },
  {
    step: "6.0",
    title: "ADMET Prediction",
    description: "Predict absorption, distribution, metabolism, excretion, and toxicity profiles.",
    tools: ["SwissADME", "pkCSM", "ADMETlab"],
    inputs: "Top docking candidates (SMILES)",
    outputs: "ADMET-filtered lead compounds",
    timeline: "2–3 days"
  },
  {
    step: "7.0",
    title: "Lead Optimization",
    description: "Optimize lead compounds for improved drug-like properties and selectivity.",
    tools: ["RDKit", "Schrödinger", "OpenBabel"],
    inputs: "ADMET-filtered leads",
    outputs: "Optimized drug candidates for synthesis",
    timeline: "5–7 days"
  }
]
