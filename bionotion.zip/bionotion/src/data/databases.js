export const databases = [
  { category: "GENOMICS" },
  { name: "TCGA", description: "Database of cancer genome atlas varieties.", link: "https://www.cancer.gov/ccg/research/genome-sequencing/tcga" },
  { name: "TargetFinder", description: "Database of promoter-enhancer interaction pairs.", link: "https://github.com/shwhalen/targetfinder" },
  { name: "ArrayExpress", description: "Database of the high-throughput functional genomics data.", link: "https://www.ebi.ac.uk/biostudies/arrayexpress" },
  { category: "TRANSCRIPTOMICS" },
  { name: "GEO", description: "Database of public functional genomics data.", link: "https://www.ncbi.nlm.nih.gov/geo/" },
  { name: "ENCODE", description: "Database of functional elements in the human genome.", link: "https://www.encodeproject.org/" },
  { category: "PROTEOMICS" },
  { name: "UniProt", description: "Database of protein sequences and functions.", link: "https://www.uniprot.org/" },
  { name: "PDB", description: "Database of 3D structural data for large biological molecules.", link: "https://www.rcsb.org/" },
  { category: "DRUG" },
  { name: "ChEMBL", description: "Database of bioactive compounds with drug-like properties.", link: "https://www.ebi.ac.uk/chembl/" },
  { name: "ZINC", description: "Database of commercially available compounds.", link: "https://zinc15.docking.org/" },
  { name: "PubChem", description: "Database of freely available chemical information.", link: "https://pubchem.ncbi.nlm.nih.gov/" },
  { category: "SINGLE CELL" },
  { name: "Single-cell Expression Atlas", description: "Database of single-cell gene expression across species.", link: "https://www.ebi.ac.uk/gxa/sc/home" },
  { name: "Human Cell Atlas", description: "Database of the multi-omic human cell atlas.", link: "https://www.humancellatlas.org/" }
]
