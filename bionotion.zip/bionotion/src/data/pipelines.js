export const nextflowPipeline = [
  {
    section: "1. Pre-processing",
    tools: ["cat", "FastQC", "Salmon (strandness)", "UMI-tools", "FastP", "Trim Galore", "SortMeRNA", "BBSplit"],
    purpose: "Concatenates raw FASTQ files, quality check, strand inference, UMI extraction, adapter trimming, rRNA removal",
    insight: "Proper experimental design is critical — accounting for biological replicates, batch effects, and sequencing depth."
  },
  {
    section: "2. Genome Alignment & Quantification",
    tools: ["STAR", "HISAT2", "featureCounts", "HTSeq", "Salmon", "kallisto"],
    purpose: "Aligns reads to reference genome, quantifies gene/transcript expression",
    insight: "Choosing aligners based on speed vs. sensitivity. STAR excels for eukaryotic spliced alignment."
  },
  {
    section: "3. Differential Expression",
    tools: ["DESeq2", "edgeR", "limma-voom"],
    purpose: "Identifies statistically significant expression differences between conditions",
    insight: "Raw counts preferred over normalized metrics for DE. DESeq2 median-of-ratios normalization is most robust."
  },
  {
    section: "4. Normalization",
    tools: ["DESeq2 median-of-ratios", "TMM (edgeR)", "TPM", "FPKM", "spike-ins"],
    purpose: "Adjusts for sequencing depth, library size differences, and gene length biases",
    insight: "TMM and DESeq2 normalization outperform simple TPM for cross-sample comparisons."
  },
  {
    section: "5. Functional Annotation & Enrichment",
    tools: ["clusterProfiler", "GSEA", "DAVID", "g:Profiler", "Enrichr"],
    purpose: "Gene ontology enrichment, pathway analysis, functional classification of DE genes",
    insight: "GSEA captures coordinated expression changes; ORA captures discrete gene set overlaps."
  },
  {
    section: "6. Visualization & Reporting",
    tools: ["ggplot2", "pheatmap", "EnhancedVolcano", "Seurat", "MultiQC"],
    purpose: "Heatmaps, volcano plots, PCA plots, UMAP for single-cell, QC aggregation",
    insight: "MultiQC across all samples spots batch effects early. Volcano plots communicate DE results effectively."
  }
]
