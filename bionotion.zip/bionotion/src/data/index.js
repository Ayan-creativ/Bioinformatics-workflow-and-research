export const workflows = {
  ngs: {
    title: "NGS (Next-Generation Sequencing)",
    steps: {
      "Data Analysis": ["FASTQC", "MultiQC", "Trimmomatic", "Cutadapt"],
      "Alignment": ["BWA", "Bowtie2", "STAR", "HISAT2"],
      "Variant Calling": ["GATK", "FreeBayes", "SAMtools"],
      "Assembly": ["SPAdes", "MEGAHIT", "SOAPdenovo"],
      "Annotation": ["Prokka", "RAST", "SnpEff"]
    }
  },
  metagenomics: {
    title: "Metagenomics",
    steps: {
      "Preprocessing": ["SortMeRNA", "Trimmomatic", "Fastp"],
      "Assembly": ["Trinity", "MEGAHIT"],
      "Quantification": ["Salmon", "Kallisto", "RSEM"],
      "Functional Annotation": ["eggNOG-mapper", "KEGG Mapper", "InterProScan"],
      "Pathway Analysis": ["MetaCyc", "MapMan"]
    }
  },
  metatranscriptomics: {
    title: "Metatranscriptomics",
    steps: {
      "Preprocessing": ["SortMeRNA", "Trimmomatic", "Fastp"],
      "Assembly": ["Trinity", "MEGAHIT"],
      "Quantification": ["Salmon", "Kallisto", "RSEM"],
      "Functional Annotation": ["eggNOG-mapper", "KEGG Mapper", "InterProScan"],
      "Pathway Analysis": ["MetaCyc", "MapMan"]
    }
  },
  network: {
    title: "Network Analysis",
    steps: {
      "Network Visualization": ["Cytoscape", "Gephi"],
      "Graph Analysis": ["igraph (R/Python)", "NetworkX (Python)"],
      "Functional Enrichment": ["STRING", "GeneMANIA"],
      "Dynamic Modeling": ["Pajek", "BioGRID"]
    }
  },
  systems: {
    title: "Systems Biology",
    steps: {
      "Modeling Tools": ["COPASI", "CellDesigner", "MATLAB SimBiology"],
      "Pathway Databases": ["KEGG", "Reactome", "BioCyc"],
      "Simulation": ["SBML", "VCell", "OpenSim"],
      "Omics Integration": ["MetaboAnalyst", "Cytoscape ClueGO"]
    }
  },
  synthetic: {
    title: "Synthetic Biology",
    steps: {
      "Design Tools": ["BioCAD", "Gene Designer", "TinkerCell"],
      "Simulation & Modeling": ["iBioSim", "SynBioSS", "COPASI"],
      "DNA Assembly": ["Golden Gate Assembly", "Gibson Assembly"],
      "Pathway Design": ["SBOL", "SBW"]
    }
  },
  genetic: {
    title: "Genetic Engineering",
    steps: {
      "Design & Simulation": ["Benchling", "Geneious", "SnapGene"],
      "CRISPR Tools": ["CRISPResso", "CHOPCHOP", "Cas-OFFinder"],
      "Primer Design": ["Primer3", "OligoAnalyzer"],
      "Cloning Tools": ["ApE", "PlasMapper"]
    }
  },
  vcf: {
    title: "VCF Analysis",
    steps: {
      "VCF Manipulation": ["VCFtools", "BCFtools"],
      "Annotation": ["ANNOVAR", "SnpEff", "VEP"],
      "Visualization": ["IGV", "JBrowse"],
      "Comparative Analysis": ["bedtools", "GATK"]
    }
  },
  proteomics: {
    title: "Proteomics",
    steps: {
      "Protein Identification": ["MaxQuant", "MSFragger", "Mascot"],
      "Protein Quantification": ["Perseus", "Spectronaut", "Skyline"],
      "Protein-Protein Interactions": ["Cytoscape", "STRING", "xiSEARCH"],
      "Structural Proteomics": ["PyMOL", "Chimera", "AlphaFold DB"],
      "PTM Analysis": ["NetPhos", "PTMProphet", "PhosphoSitePlus"],
      "Clinical Proteomics": ["SPOT", "AutoDock", "Schrödinger"]
    }
  },
  nextflow: {
    title: "Nextflow Pipeline (RNA-seq)",
    steps: {
      "1. Pre-processing": ["cat → FastQC", "Salmon (strandness)", "UMI-tools extract", "FastP → Trim Galore", "SortMeRNA → BBSplit"],
      "2. Genome Alignment": ["STAR → HISAT2", "RSEM → Salmon", "UMI-tools dedup"],
      "3. Pseudo-alignment": ["Salmon → Kallisto", "MultiQC"],
      "4. Post-processing": ["SAMtools", "Picard MarkDuplicates", "BEDtools → BigWig", "StringTie"],
      "5. Final QC": ["Kraken2 → Bracken", "dupRadar", "Preseq", "DESeq2 PCA", "Qualimap", "RSeQC"]
    }
  }
};

export const biomarkers = [
  { organ: "Thyroid", markers: "CEA, Thyroglobulin", detection: "Blood test (serum marker analysis)", databases: "CGMD, TCGA", pipelines: "CAMPP, TronFlow" },
  { organ: "Lung", markers: "CEA, CA-125, Cyfra 21-1", detection: "Blood test, biopsy, imaging (CT)", databases: "CPTAC, ICGC", pipelines: "TronFlow Mutect2" },
  { organ: "Breast (in females)", markers: "CEA, CA 15-3", detection: "Blood test, mammography, ultrasound", databases: "CGMD, KEGG, UniProtKB", pipelines: "GATK workflows" },
  { organ: "Esophagus", markers: "CEA, CSS", detection: "Blood test, endoscopy", databases: "TCGA, COSMIC", pipelines: "Snakemake workflows" },
  { organ: "Liver/Bile Duct", markers: "CEA, AFP, CA 19-9", detection: "Blood test, ultrasound, CT", databases: "HCCDB, CGMD", pipelines: "CAMPP" },
  { organ: "Stomach/Pancreas", markers: "CEA, CA 19-9, CA 72-4", detection: "Blood test, endoscopy, imaging", databases: "TCGA, Pancreatic Expression DB", pipelines: "TronFlow" },
  { organ: "Colorectal", markers: "CEA, CA 19-9, M2-PK", detection: "Blood test, stool test, colonoscopy", databases: "CPTAC Colorectal Data", pipelines: "OncoSeek AI" },
  { organ: "Ovaries (in females)", markers: "CA-125, CA 72-4", detection: "Blood test, pelvic ultrasound", databases: "TCGA Ovarian Data", pipelines: "CAMPP multi-marker" },
  { organ: "Uterus (in females)", markers: "CEA, CA-125, SCC", detection: "Blood test, pelvic ultrasound", databases: "CGMD", pipelines: "SnpEff / BCFtools" },
  { organ: "Prostate (in males)", markers: "PSA, FPSA and ratio", detection: "Blood test (PSA levels), digital rectal exam", databases: "Prostate Cancer Transcriptome Atlas", pipelines: "GATK germline" },
  { organ: "Testis (in males)", markers: "AFP, BHCG", detection: "Blood test, ultrasound", databases: "CGMD", pipelines: "HaplotypeCaller" },
  { organ: "Metastasis to Bone", markers: "CEA", detection: "Blood test, bone scan", databases: "COSMIC", pipelines: "CNVkit" }
];

export const llms = [
  { name: "BioGPT", base: "GPT architecture", fields: "Medical literature, Drug discovery", arch: "Transformer domain-specific", score: "82.9% F1 NER", source: "Open source", size: "1.5B params" },
  { name: "PubMedBERT", base: "BERT", fields: "Biomedical text mining", arch: "Bidirectional encoder", score: "85.7% relation extraction", source: "Open source", size: "110M params" },
  { name: "GatorTron", base: "GPT-3", fields: "Clinical documentation", arch: "Transformer clinical", score: "90.2% clinical prediction", source: "Closed source", size: "8.9B params" },
  { name: "BioBERT", base: "BERT", fields: "Genomics, Molecular biology", arch: "Bidirectional domain adapt.", score: "89.5% NER", source: "Open source", size: "345M params" },
  { name: "ClinicalBERT", base: "BERT", fields: "Clinical care, Patient outcomes", arch: "Clinical language BERT", score: "87.8% outcome prediction", source: "Open source", size: "110M params" },
  { name: "Med-PaLM 2", base: "PaLM architecture", fields: "Clinical reasoning", arch: "Large-scale medical LM", score: "92.6% medical licensing exam", source: "Closed source", size: "540B params" },
  { name: "DRAGON", base: "GPT + domain adapt.", fields: "Proteomics, Drug discovery", arch: "Protein language model", score: "88.3% function prediction", source: "Open source", size: "2.1B params" },
  { name: "SciFive", base: "T5 architecture", fields: "Cross-domain science", arch: "Text-to-text transfer", score: "84.5% scientific QA", source: "Open source", size: "770M params" },
  { name: "GenSLMs", base: "Transformer", fields: "Genomics, Variant interpretation", arch: "Genomic sequence model", score: "86.7% variant classification", source: "Closed source", size: "5.2B params" },
  { name: "BioMegatron", base: "Megatron-LM", fields: "Drug development, Clinical trials", arch: "Large-scale biomedical LM", score: "91.2% drug-target prediction", source: "Closed source", size: "11B params" },
  { name: "DeepSeek", base: "Custom architecture", fields: "Multi-omics, Precision medicine", arch: "Deep learning omics", score: "89.4% multi-omics prediction", source: "Open source", size: "3.2B params" },
  { name: "DeepPBS", base: "Geometric Deep Learning", fields: "Bioinformatics, Structural Biology", arch: "Graph-based neural networks", score: "High accuracy (PDB validated)", source: "Open source", size: "Not specified" },
  { name: "PeSTo", base: "Geometric Deep Learning", fields: "Molecular Modeling", arch: "Transformer-based", score: "10% better AUC vs baselines", source: "Open source", size: "Not specified" },
  { name: "RoseTTAFold2NA", base: "Deep Learning (RoseTTAFold)", fields: "Structural Biology", arch: "Deep neural networks 3D", score: "RMSD ~1.5Å", source: "Open source", size: "Not specified" }
];

export const databases = [
  { name: "TCGA", category: "GENOMICS", description: "Database of cancer genome atlas varieties.", url: "https://www.cancer.gov/ccg/research/genome-sequencing/tcga" },
  { name: "TargetFinder", category: "GENOMICS", description: "Database of promoter-enhancer interaction pairs.", url: "https://github.com/shwhalen/targetfinder" },
  { name: "ArrayExpress", category: "GENOMICS", description: "Database of high-throughput functional genomics data.", url: "https://www.ebi.ac.uk/biostudies/arrayexpress" },
  { name: "GEO", category: "TRANSCRIPTOMICS", description: "Database of public functional genomics data.", url: "https://www.ncbi.nlm.nih.gov/geo/" },
  { name: "ENCODE", category: "TRANSCRIPTOMICS", description: "Database of functional elements in the human genome.", url: "https://www.encodeproject.org/" },
  { name: "UniProt", category: "PROTEOMICS", description: "Database of protein sequences and functions.", url: "https://www.uniprot.org/" },
  { name: "PDB", category: "PROTEOMICS", description: "Database of 3D structural data for large biological molecules.", url: "https://www.rcsb.org/" },
  { name: "ChEMBL", category: "DRUG", description: "Database of bioactive compounds with drug-like properties.", url: "https://www.ebi.ac.uk/chembl/" },
  { name: "ZINC", category: "DRUG", description: "Database of commercially available compounds.", url: "https://zinc15.docking.org/" },
  { name: "PubChem", category: "DRUG", description: "Database of freely available chemical information.", url: "https://pubchem.ncbi.nlm.nih.gov/" },
  { name: "Single-cell Expression Atlas", category: "SINGLE CELL", description: "Database of single-cell gene expression across species.", url: "https://www.ebi.ac.uk/gxa/sc/home" },
  { name: "Human Cell Atlas", category: "SINGLE CELL", description: "Database of the multi-omic human cell atlas.", url: "https://www.humancellatlas.org/" }
];

export const foundationModelsProteomics = [
  { name: "UniRep", type: "LANGUAGE FM", arch: "mLSTM, 18.2M params", desc: "Protein engineering, Remote homologies, Mutation effects" },
  { name: "MSA Transformer", type: "LANGUAGE FM", arch: "Transformer, 100M params", desc: "Contact prediction, Secondary structure prediction" },
  { name: "ProtTrans", type: "LANGUAGE FM", arch: "Transformer, 11B params", desc: "Subcellular localization, Secondary structure prediction" },
  { name: "ProteinBERT", type: "LANGUAGE FM", arch: "Transformer, 16M params", desc: "Remote homology, Fluorescence, Stability, Secondary structure" },
  { name: "ProtGPT2", type: "LANGUAGE FM", arch: "Autoregressive Transformer", desc: "Protein sequence generation" },
  { name: "ESM2", type: "LANGUAGE FM", arch: "Transformer, 15B params", desc: "Contact prediction, PPI, Remote homology, Fluorescence, Stability" },
  { name: "ProGen", type: "LANGUAGE FM", arch: "Autoregressive, 1.2B params", desc: "Protein sequence design" },
  { name: "OntoProtein", type: "MULTIMODAL FM", arch: "BERT + Knowledge Graph", desc: "Contact, PPI, Homology, GO prediction, Secondary structure" },
  { name: "AlphaFold3", type: "MULTIMODAL FM", arch: "Diffusion model", desc: "Protein-ligand, Protein-nucleic acid, Antibody-antigen, Structure" }
];

export const dataLandscape = [
  { category: "Whole Genome Data", subcategory: "Raw Sequencing Reads", info: "DNA sequences, quality scores", formats: "FASTQ, BAM, CRAM", tools: "BWA, Bowtie2" },
  { category: "Whole Genome Data", subcategory: "Structural Variants", info: "Insertions, deletions, inversions", formats: "VCF, BED", tools: "Delly, Manta" },
  { category: "Transcriptomics", subcategory: "Bulk RNA-Seq", info: "Gene expression, alternative splicing", formats: "FASTQ, BAM, GTF", tools: "STAR, HISAT2, DESeq2" },
  { category: "Transcriptomics", subcategory: "Single-Cell RNA-Seq", info: "Cell-specific gene expression", formats: "FASTQ, BAM, HDF5", tools: "CellRanger, Seurat" },
  { category: "Epigenomics", subcategory: "DNA Methylation", info: "Methylation patterns (CpG islands)", formats: "BAM, BED, WIG", tools: "Bismark, MethPipe" },
  { category: "Epigenomics", subcategory: "ChIP-Seq", info: "Protein-DNA interactions", formats: "BED, BAM, FASTQ", tools: "MACS2, HOMER" },
  { category: "Proteomics", subcategory: "Protein Structures", info: "3D spatial arrangement of proteins", formats: "PDB, mmCIF", tools: "PyMOL, Chimera" },
  { category: "Metagenomics", subcategory: "Shotgun Sequencing", info: "Genomes of all organisms in a sample", formats: "FASTQ, FASTA", tools: "MetaSPAdes, Kraken" },
  { category: "Variant Data", subcategory: "Somatic Variants", info: "Cancer-associated mutations", formats: "VCF, BAM", tools: "MuTect2, Strelka" },
  { category: "Synthetic Biology", subcategory: "Designed Sequences", info: "Artificial DNA/RNA sequences", formats: "GenBank, FASTA", tools: "SnapGene, Benchling" }
];

export const navItems = [
  { id: "workflows", label: "Workflows", icon: "⚙" },
  { id: "biomarkers", label: "Detailed Biomarkers", icon: "🧬" },
  { id: "databases", label: "Biological Databases", icon: "🗄" },
  { id: "llms", label: "LLMs", icon: "🤖" },
  { id: "foundation", label: "Foundation Models", icon: "🔬" },
  { id: "landscape", label: "Data Landscape", icon: "📊" }
];
