import React from 'react'
import styles from './LeftPanel.module.css'

const VIEW_OPTIONS = [
  { value: 'biomarkers', label: 'Detailed Biomarkers' },
  { value: 'databases', label: 'Biological databases used for Foundation Models' },
  { value: 'workflows', label: 'Bioinformatics WorkFlows' },
  { value: 'llms', label: 'LLMs' },
  { value: 'proteomics', label: 'Proteomics' },
  { value: 'pipelines', label: 'Nextflow Pipeline' },
]

const VISUAL_OPTIONS = [
  { value: 'biomarker', label: 'Biomarker' },
  { value: 'workflow', label: 'Workflow Diagram' },
  { value: 'database', label: 'Database Map' },
]

export default function LeftPanel({ activeView, onViewChange, activeVisual, onVisualChange }) {
  return (
    <div className={styles.panel}>
      <div className={styles.top}>

        {/* Main table dropdown */}
        <div className={styles.mainDropdown}>
          <div className={styles.mainDropdownInner}>
            <select
              value={activeView}
              onChange={e => onViewChange(e.target.value)}
              className={styles.mainSelect}
            >
              {VIEW_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <span className={styles.arrow}>▼</span>
          </div>
        </div>

        {/* Purpose box */}
        <div className={styles.purposeBox}>
          <p className={styles.purposeTitle}>Quick Access Sheet</p>
          <p className={styles.purposeSubtitle}>Purpose:</p>
          <p className={styles.purposeText}>
            This sheet is designed for quickly retrieving and viewing relevant data.
          </p>
          <p className={styles.purposeText} style={{ marginTop: 6 }}>
            It should NOT be used to modify new entries. No manual edits should be made in this sheet.
          </p>
          <p className={styles.rule}>Rules: <em>75% Size recommended</em></p>
          <p className={styles.purposeText}>
            Users can select from the dropdowns to dynamically change the displayed table &amp; respective images.
          </p>
          <p className={styles.purposeText} style={{ marginTop: 6 }}>
            All data modifications must be performed in the designated update sections.
          </p>
        </div>
      </div>

      {/* Visuals dropdown — pinned to bottom */}
      <div className={styles.visualDropdown}>
        <div className={styles.visualInner}>
          <span className={styles.visualLabel}>Visuals</span>
          <div className={styles.visualSelectWrap}>
            <select
              value={activeVisual}
              onChange={e => onVisualChange(e.target.value)}
              className={styles.visualSelect}
            >
              {VISUAL_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <span className={styles.arrow}>▼</span>
          </div>
        </div>
      </div>
    </div>
  )
}
