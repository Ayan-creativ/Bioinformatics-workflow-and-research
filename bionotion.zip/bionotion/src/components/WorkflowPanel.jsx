import React from 'react'
import { workflows, workflowOptions } from '../data/workflows.js'
import styles from './WorkflowPanel.module.css'

export default function WorkflowPanel({ selected, onSelect }) {
  const wf = workflows[selected]

  return (
    <div className={styles.panel}>
      {/* Workflow selector */}
      <div className={styles.selectorRow}>
        <div className={styles.selectWrap}>
          <select
            value={selected}
            onChange={e => onSelect(e.target.value)}
            className={styles.wfSelect}
          >
            {workflowOptions.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
          <span className={styles.arrow}>▼</span>
        </div>
        <span className={styles.wfTitleBadge}>{wf.title}</span>
      </div>

      {/* Workflow table */}
      <div className={styles.tableWrap}>
        <div className={styles.navBar}>⟵⟵⟵ Workflows</div>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Category</th>
              <th>Tools</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(wf.steps).map(([step, tools], i) => (
              <tr key={step} className={i % 2 === 1 ? styles.altRow : ''}>
                <td className={styles.stepCell}>{step}</td>
                <td>
                  {tools.map(t => (
                    <span key={t} className={styles.toolChip}>{t}</span>
                  ))}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className={styles.footer}>
          <span className={styles.footerLink}>🎥 Videos</span>
          <span className={styles.footerLink}>📄 Scientific Papers</span>
        </div>
      </div>
    </div>
  )
}
