import React from 'react'
import { biomarkers } from '../data/biomarkers.js'
import { databases } from '../data/databases.js'
import { llms } from '../data/llms.js'
import { proteomicsSteps } from '../data/proteomics.js'
import { nextflowPipeline } from '../data/pipelines.js'
import { workflows, workflowOptions } from '../data/workflows.js'
import styles from './DataPanel.module.css'

function IndexBar({ desc }) {
  return (
    <div className={styles.indexBar}>
      <span className={styles.indexLabel}>Index</span>
      <span className={styles.indexDesc}>{desc}</span>
    </div>
  )
}

function SectionHeader({ title, sub }) {
  return (
    <div className={styles.sectionHeader}>
      <div>{title}</div>
      {sub && <div className={styles.sectionSub}>{sub}</div>}
    </div>
  )
}

function BiomarkersView() {
  return (
    <>
      <IndexBar desc="Organ/System → Tumor Markers → Detection Methods → Relevant Databases → Existing Pipelines" />
      <SectionHeader title="Detailed Biomarkers" sub="Tumor Markers by Organ / System" />
      <div className={styles.tableScroll}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Organ / System</th>
              <th>Tumor Markers</th>
              <th>Detection Methods</th>
              <th>Databases</th>
              <th>Pipelines / Tools</th>
            </tr>
          </thead>
          <tbody>
            {biomarkers.map((row, i) => (
              <tr key={row.organ} className={i % 2 === 1 ? styles.altRow : ''}>
                <td className={styles.organCell}>{row.organ}</td>
                <td>{row.markers.map(m => <span key={m} className={styles.markerChip}>{m}</span>)}</td>
                <td className={styles.smallCell}>{row.detection}</td>
                <td>{row.db.map(d => <span key={d} className={styles.dbChip}>{d}</span>)}</td>
                <td className={styles.smallCell}>{row.pipelines.join(', ')}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

function DatabasesView() {
  return (
    <>
      <IndexBar desc="A catalog of major biological databases (e.g., UniProt, PDB, ENSEMBL) that support training and development of foundation models" />
      <SectionHeader title="Biological databases used for Foundation Models" />
      <div className={styles.tableScroll}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Database</th>
              <th>Description</th>
              <th>Web Link</th>
            </tr>
          </thead>
          <tbody>
            {databases.map((row, i) => {
              if (row.category) {
                return (
                  <tr key={row.category} className={styles.catRow}>
                    <td colSpan={3}>— {row.category} —</td>
                  </tr>
                )
              }
              return (
                <tr key={row.name} className={i % 2 === 1 ? styles.altRow : ''}>
                  <td className={styles.dbNameCell}>{row.name}</td>
                  <td className={styles.smallCell}>{row.description}</td>
                  <td className={styles.linkCell}>
                    <a href={row.link} target="_blank" rel="noreferrer">{row.link.replace('https://', '')}</a>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </>
  )
}

function LLMsView() {
  return (
    <>
      <IndexBar desc="Foundation models and LLMs used in bioinformatics research — architecture, fields, scores, strengths & limitations" />
      <SectionHeader title="LLMs & Foundation Models in Bioinformatics" />
      <div className={styles.tableScroll}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Model / Company</th>
              <th>Architecture</th>
              <th>Fields</th>
              <th>Score Achieved</th>
              <th>Strengths</th>
              <th>Limitations</th>
            </tr>
          </thead>
          <tbody>
            {llms.map((row, i) => (
              <tr key={row.name} className={i % 2 === 1 ? styles.altRow : ''}>
                <td className={styles.dbNameCell}>{row.name}</td>
                <td className={styles.monoCell}>{row.basedOn}</td>
                <td><span className={styles.dbChip}>{row.fields}</span></td>
                <td className={styles.scoreCell}>{row.score}</td>
                <td className={styles.strengthCell}>{row.strengths}</td>
                <td className={styles.limitCell}>{row.limitations}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

function ProteomicsView() {
  return (
    <>
      <IndexBar desc="Bioinformatics & Chemoinformatics Workflow for Drug Development from Protein Targets" />
      <SectionHeader title="Proteomics → Drug Development Workflow" sub="DNA-to-Drug continuum pipeline" />
      <div className={styles.tableScroll}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Step</th>
              <th>Title</th>
              <th>Description</th>
              <th>Tools / Resources</th>
              <th>Outputs</th>
              <th>Timeline</th>
            </tr>
          </thead>
          <tbody>
            {proteomicsSteps.map((row, i) => (
              <tr key={row.step} className={i % 2 === 1 ? styles.altRow : ''}>
                <td className={styles.stepNumCell}>{row.step}</td>
                <td className={styles.dbNameCell}>{row.title}</td>
                <td className={styles.smallCell}>{row.description}</td>
                <td>{row.tools.map(t => <span key={t} className={styles.toolChip}>{t}</span>)}</td>
                <td className={styles.smallCell}>{row.outputs}</td>
                <td className={styles.timelineCell}>{row.timeline}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

function PipelinesView() {
  return (
    <>
      <IndexBar desc="Nextflow pipeline — bulk RNA-seq 6-section comprehensive workflow with tools, purpose, and expert insights" />
      <SectionHeader title="Nextflow Pipeline" sub="Bulk RNA-seq Comprehensive Workflow" />
      <div className={styles.tableScroll}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Section</th>
              <th>Tools (in sequence)</th>
              <th>Purpose</th>
              <th>Insight</th>
            </tr>
          </thead>
          <tbody>
            {nextflowPipeline.map((row, i) => (
              <tr key={row.section} className={i % 2 === 1 ? styles.altRow : ''}>
                <td className={styles.dbNameCell}>{row.section}</td>
                <td>{row.tools.map(t => <span key={t} className={styles.toolChip}>{t}</span>)}</td>
                <td className={styles.smallCell}>{row.purpose}</td>
                <td className={styles.insightCell}>{row.insight}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

function WorkflowsListView() {
  return (
    <>
      <IndexBar desc="Select a workflow from the top dropdown to view its full pipeline" />
      <SectionHeader title="Bioinformatics WorkFlows" sub="8 specialised pipelines" />
      <div className={styles.tableScroll}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Workflow</th>
              <th>Pipeline Steps</th>
            </tr>
          </thead>
          <tbody>
            {workflowOptions.map((opt, i) => (
              <tr key={opt.value} className={i % 2 === 1 ? styles.altRow : ''}>
                <td className={styles.dbNameCell}>{opt.label}</td>
                <td className={styles.smallCell}>
                  {Object.keys(workflows[opt.value].steps).join(' → ')}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}

export default function DataPanel({ activeView }) {
  return (
    <div className={styles.panel}>
      {activeView === 'biomarkers' && <BiomarkersView />}
      {activeView === 'databases' && <DatabasesView />}
      {activeView === 'llms' && <LLMsView />}
      {activeView === 'proteomics' && <ProteomicsView />}
      {activeView === 'pipelines' && <PipelinesView />}
      {activeView === 'workflows' && <WorkflowsListView />}
    </div>
  )
}
