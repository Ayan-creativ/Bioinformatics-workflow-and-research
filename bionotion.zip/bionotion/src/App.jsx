import React, { useState } from 'react'
import LeftPanel from './components/LeftPanel.jsx'
import DataPanel from './components/DataPanel.jsx'
import WorkflowPanel from './components/WorkflowPanel.jsx'
import styles from './App.module.css'

export default function App() {
  const [activeView, setActiveView] = useState('biomarkers')
  const [activeVisual, setActiveVisual] = useState('biomarker')
  const [activeWorkflow, setActiveWorkflow] = useState('metagenomics')

  return (
    <div className={styles.app}>
      {/* Header bar */}
      <header className={styles.header}>
        <span className={styles.logo}>BioNotion</span>
        <span className={styles.tagline}>Bioinformatics Research Dashboard</span>
        <nav className={styles.tabs}>
          <span className={styles.tab}>Quick Access</span>
          <span className={styles.tab}>Guide</span>
          <span className={styles.tab}>Proteomics</span>
          <span className={styles.tab}>Pipelines</span>
          <span className={styles.tab}>All</span>
          <span className={styles.tab}>Ideas</span>
          <span className={styles.tab}>Docs</span>
        </nav>
      </header>

      {/* Main layout */}
      <main className={styles.main}>
        <aside className={styles.left}>
          <LeftPanel
            activeView={activeView}
            onViewChange={setActiveView}
            activeVisual={activeVisual}
            onVisualChange={setActiveVisual}
          />
        </aside>

        <section className={styles.dataSection}>
          <DataPanel activeView={activeView} />
        </section>

        <section className={styles.workflowSection}>
          <WorkflowPanel
            selected={activeWorkflow}
            onSelect={setActiveWorkflow}
          />
        </section>
      </main>
    </div>
  )
}
